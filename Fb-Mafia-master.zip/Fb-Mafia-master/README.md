<p align="left">

<a href="#"><img title="Made in Pakistan" src="https://img.shields.io/badge/MADE%20IN-PAKISTAN-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>


### Fb Mafia Installation ❕

- `apt update && apt upgrade `

- ` apt install git`

- ` apt install python2 `

- `git clone https://github.com/Tech-abm/Fb-Mafia`

- `cd Fb-Mafia`

- `pip2 install mechanize`

- `pip2 install requests `

- `python2 Dark-Cloning.py`


 > I am not responsible for this Tools

 > Version 2.0
![PicsArt_08-30-11.31.36.jpg](https://user-images.githubusercontent.com/52023076/91666789-94390880-eab4-11ea-8b54-83a3a0d487f0.jpg)

























